# tensformer.py
# Tensional Intelligence Core Prototype
# (Simplified conceptual prototype for GitHub upload)

class TensionNode:
    def __init__(self, name, value=0.0):
        self.name = name
        self.value = value
        self.links = {}

    def connect(self, other, weight):
        self.links[other] = weight

    def tension(self):
        return sum(weight * abs(self.value - node.value) for node, weight in self.links.items())

class TensionNetwork:
    def __init__(self):
        self.nodes = {}

    def add_node(self, name, value=0.0):
        node = TensionNode(name, value)
        self.nodes[name] = node
        return node

    def connect(self, name1, name2, weight=1.0):
        self.nodes[name1].connect(self.nodes[name2], weight)
        self.nodes[name2].connect(self.nodes[name1], weight)

    def total_tension(self):
        return sum(node.tension() for node in self.nodes.values()) / 2

    def adjust(self, lr=0.01):
        for node in self.nodes.values():
            grad = sum(weight * (node.value - other.value)
                       for other, weight in node.links.items())
            node.value -= lr * grad

if __name__ == "__main__":
    net = TensionNetwork()
    net.add_node("A", 0.2)
    net.add_node("B", 0.8)
    net.add_node("C", 0.5)
    net.connect("A", "B", 1.0)
    net.connect("B", "C", 0.5)
    net.connect("A", "C", 0.3)

    for step in range(50):
        net.adjust(0.05)
        print(f"Step {step}: Total Tension = {net.total_tension():.4f}")
